/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ejemploherenciavehiculos.herencia;

/**
 *
 * @author vickyfg
 */
public class Herencia {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
