/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercrecursividad;

/**
 *
 * @author vickyfg
 */
public class Numeros {
    
    //Recorrer un array de forma recursiva e imprimir los valores
       

    }
        
    
    
}
    