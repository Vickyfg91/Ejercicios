/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercrecursividad;

/**
 *
 * @author vickyfg
 */
public class EjercRecursividad {
    //1- Recorrer un array de forma recursiva e imprimir los valores
    
    //2- Sumar de forma recursiva los elementos de un array
    
    //3- Clase carrito
    public static void main(String[] args) {
       int[]arrayNumeros = new int[10];
       arrayNumeros[0] = 1;        
       arrayNumeros[1] = 2;
       arrayNumeros[2] = 3; 
       arrayNumeros[3] = 4; 
       arrayNumeros[4] = 5; 
       arrayNumeros[5] = 6; 
       arrayNumeros[6] = 7; 
       arrayNumeros[7] = 8; 
       arrayNumeros[8] = 9; 
       arrayNumeros[9] = 10; 
       
       
    }
    
   public static void recorrerArrayFRecursiva(int[] arrayNumeros){
       if 
   }
        
        
    
}
