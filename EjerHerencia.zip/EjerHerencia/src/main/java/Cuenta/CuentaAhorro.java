/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cuenta;

/**
 *
 * @author vickyf
 */
//public class CuentaAhorro extends Cuenta {

    //private double interesVariable;
    //private double comisionAnual;
/*
    public CuentaAhorro(Persona cliente, double interesVariable, double comisionAnual) {
        super(cliente);
        this.interesVariable = interesVariable;
        this.comisionAnual = comisionAnual;
    }

    public double getInteresVariable() {
        return interesVariable;
    }

    public void setInteresVariable(double interesVariable) {
        this.interesVariable = interesVariable;
    }

    public double getComisionAnual() {
        return comisionAnual;
    }

    public void setComisionAnual(double comisionAnual) {
        this.comisionAnual = comisionAnual;
    }

    @Override
    public void actualizarSaldo() {
        // Abona el interés variable al saldo
        saldo += saldo * interesVariable;
        // Cobra la comisión anual
        saldo -= comisionAnual;
    }

    @Override
    public void retirar(double cantidad) {
        if (saldo - cantidad >= 0) {
            saldo -= cantidad;
        } else {
            System.out.println("Saldo insuficiente para realizar la retirada.");
        }
    }

    @Override
    public String toString() {
        return super.toString() +
                ", interesVariable=" + interesVariable +
                ", comisionAnual=" + comisionAnual
                }*/

